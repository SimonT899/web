package hkmu.campus380f.dao;

import hkmu.campus380f.exception.AttachmentNotFound;
import hkmu.campus380f.exception.BookNotFound;
import hkmu.campus380f.model.Attachment;
import hkmu.campus380f.model.Book;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Service
public class BookService {
    @Resource
    private BookRepository tRepo;
    @Resource
    private AttachmentRepository aRepo;

    @Transactional
    public List<Book> getBooks() {
        return tRepo.findAll();
    }

    @Transactional
    public Book getBook(long id)
            throws BookNotFound {
        Book book = tRepo.findById(id).orElse(null);
        if (book == null) {
            throw new BookNotFound(id);
        }
        return book;
    }

    @Transactional
    public Attachment getAttachment(long bookId, UUID attachmentId)
            throws BookNotFound, AttachmentNotFound {
        Book book = tRepo.findById(bookId).orElse(null);
        if (book == null) {
            throw new BookNotFound(bookId);
        }
        Attachment attachment = aRepo.findById(attachmentId).orElse(null);
        if (attachment == null) {
            throw new AttachmentNotFound(attachmentId);
        }
        return attachment;
    }

    @Transactional(rollbackFor = BookNotFound.class)
    public void delete(long id) throws BookNotFound {
        Book deletedBook = tRepo.findById(id).orElse(null);
        if (deletedBook == null) {
            throw new BookNotFound(id);
        }
        tRepo.delete(deletedBook);
    }

    @Transactional(rollbackFor = AttachmentNotFound.class)
    public void deleteAttachment(long bookId, UUID attachmentId)
            throws BookNotFound, AttachmentNotFound {
        Book book = tRepo.findById(bookId).orElse(null);
        if (book == null) {
            throw new BookNotFound(bookId);
        }
        for (Attachment attachment : book.getAttachments()) {
            if (attachment.getId().equals(attachmentId)) {
                book.deleteAttachment(attachment);
                tRepo.save(book);
                return;
            }
        }
        throw new AttachmentNotFound(attachmentId);

    }
    @Transactional
    public long createBook(String bookName, String author,
                             String publish, List<MultipartFile> attachments)
            throws IOException {
        Book book = new Book();
        book.setBookName(bookName);
        book.setAuthor(author);
        book.setPublish(publish);
        for (MultipartFile filePart : attachments) {
            Attachment attachment = new Attachment();
            attachment.setName(filePart.getOriginalFilename());
            attachment.setMimeContentType(filePart.getContentType());
            attachment.setContents(filePart.getBytes());
            attachment.setBook(book);
            if (attachment.getName() != null && attachment.getName().length() > 0
                    && attachment.getContents() != null
                    && attachment.getContents().length > 0) {
                book.getAttachments().add(attachment);
            }
        }
        Book savedBook = tRepo.save(book);
        return savedBook.getId();
    }
    @Transactional(rollbackFor = BookNotFound.class)
    public void updateBook(long id,String bookName ,String author,
                             String publish, List<MultipartFile> attachments)
            throws IOException, BookNotFound {
        Book updatedBook = tRepo.findById(id).orElse(null);
        if (updatedBook == null) {
            throw new BookNotFound(id);
        }
        updatedBook.setBookName(bookName);
        updatedBook.setAuthor(author);
        updatedBook.setPublish(publish);
        for (MultipartFile filePart : attachments) {
            Attachment attachment = new Attachment();
            attachment.setName(filePart.getOriginalFilename());
            attachment.setMimeContentType(filePart.getContentType());
            attachment.setContents(filePart.getBytes());
            attachment.setBook(updatedBook);
            if (attachment.getName() != null && attachment.getName().length() > 0
                    && attachment.getContents() != null
                    && attachment.getContents().length > 0) {
                updatedBook.getAttachments().add(attachment);
            }
        }
        tRepo.save(updatedBook);
    }
}
