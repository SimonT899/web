package hkmu.campus380f.dao;

import hkmu.campus380f.model.BookUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookUserRepository extends JpaRepository<BookUser, String> {
}
