package hkmu.campus380f.dao;

import hkmu.campus380f.model.BookUser;
import jakarta.annotation.Resource;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserManagementService {
    @Resource
    private BookUserRepository tuRepo;

    @Transactional
    public List<BookUser> getBookUsers(){
        return tuRepo.findAll();
    }
    @Transactional
    public void delete(String username) {
        BookUser bookUser = tuRepo.findById(username).orElse(null);
        if (bookUser == null) {
            throw new UsernameNotFoundException("User '" + username + "' not found.");
        }
        tuRepo.delete(bookUser);
    }
    @Transactional
    public void createBookUser(String username, String password, String[] roles) {
        BookUser user = new BookUser(username, password, roles);
        tuRepo.save(user);
    }
}

