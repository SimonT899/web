package hkmu.campus380f.exception;

import hkmu.campus380f.model.Book;

public class BookNotFound extends Exception {
    public BookNotFound(long id) {
        super("Book " + id + " does not exist.");
    }
}
