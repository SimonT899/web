INSERT INTO users VALUES ('Nelson', '{noop}Nelsonpw');
INSERT INTO user_roles(username, role) VALUES ('Nelson', 'ROLE_ADMIN');
INSERT INTO users VALUES ('johnny', '{noop}johnnypw');
INSERT INTO user_roles(username, role) VALUES ('johnny', 'ROLE_USER');
INSERT INTO users VALUES ('simon', '{noop}simonpw');
INSERT INTO user_roles(username, role) VALUES ('simon', 'ROLE_USER');